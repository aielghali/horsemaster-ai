# 🏇 HorseMaster

## نظام ترشيحات سباقات الخيل العالمي

![Version](https://img.shields.io/badge/version-2.0-green)
![Python](https://img.shields.io/badge/python-3.11-blue)
![Flask](https://img.shields.io/badge/flask-2.3-lightgrey)

---

## 🌍 الدول المدعومة

| الدولة | المضامير | الحالة |
|--------|----------|--------|
| 🇦🇪 الإمارات | Meydan, Jebel Ali, Al Ain, Abu Dhabi, Sharjah | ✅ |
| 🇬🇧 بريطانيا | Ascot, Newmarket, Epsom, Kempton, Lingfield, Sandown, Goodwood, York, Cheltenham, Aintree | ✅ |
| 🇦🇺 أستراليا | Flemington, Randwick, Caulfield, Moonee Valley, Doomben | ✅ |
| 🇺🇸 أمريكا | Churchill Downs, Santa Anita, Belmont, Saratoga, Del Mar | ✅ |
| 🇫🇷 فرنسا | Longchamp, Chantilly, Deauville, Marseille | ✅ |
| 🇮🇪 أيرلندا | Curragh, Leopardstown, Galway | ✅ |
| 🇸🇦 السعودية | King Abdulaziz | ✅ |
| 🇶🇦 قطر | Al Rayyan | ✅ |

---

## 📁 هيكل المشروع

```
HorseMaster/
├── app.py                 # التطبيق الرئيسي (Flask)
├── requirements.txt       # المكتبات المطلوبة
├── Procfile              # تعليمات Heroku
├── runtime.txt           # إصدار Python
├── templates/
│   └── index.html        # واجهة المستخدم
├── static/
│   ├── css/
│   │   └── style.css     # التنسيقات
│   └── js/
│       └── app.js        # JavaScript
├── bots/
│   └── data_collector.py # روبوت جمع البيانات
└── data/                 # ملفات البيانات
```

---

## 🚀 التشغيل المحلي

### 1. تثبيت المكتبات
```bash
pip install -r requirements.txt
```

### 2. تشغيل التطبيق
```bash
python app.py
```

### 3. فتح المتصفح
```
http://localhost:5000
```

---

## ☁️ النشر على Heroku

### 1. تسجيل الدخول
```bash
heroku login
```

### 2. إنشاء تطبيق جديد
```bash
heroku create horsemaster-app
```

### 3. رفع المشروع
```bash
git init
git add .
git commit -m "Initial commit"
git push heroku master
```

### 4. فتح التطبيق
```bash
heroku open
```

---

## 🔌 API Endpoints

| Endpoint | Method | الوصف |
|----------|--------|-------|
| `/` | GET | الصفحة الرئيسية |
| `/api/tracks` | GET | قائمة المضامير |
| `/api/tracks/<country>` | GET | مضامير دولة معينة |
| `/api/predictions` | POST | الحصول على الترشيحات |
| `/api/live/<country>` | GET | السباقات المباشرة |
| `/api/search` | POST | البحث عن حصان |

---

## 📊 نموذج الترشيحات

يستخدم النظام 17+ عامل للتحليل:

1. **الفورم (25%)** - آخر 6 سباقات
2. **الرايتنج (20%)** - التقييم الرسمي
3. **الفارس (15%)** - خبرة وأداء الفارس
4. **المدرب (15%)** - معدل فوز الإسطبل
5. **البوابة (10%)** - تأثير مكان البداية
6. **المسافة (10%)** - ملاءمة المسافة
7. **حالة الأرض (5%)** - تفضيل نوع الأرض

---

## 🤖 الروبوت (Data Bot)

يجمع البيانات من المصادر التالية:

- **Dubai Racing Club** - سباقات الإمارات
- **Racing Post** - سباقات بريطانيا
- **At The Races** - سباقات بريطانيا وأيرلندا
- **Racing Australia** - سباقات أستراليا
- **Equibase** - سباقات أمريكا
- **France Galop** - سباقات فرنسا

---

## 📧 التواصل

- **المطور:** Elghali AI
- **الإيميل:** ai.elghali.ali@gmail.com
- **الموقع:** https://elghali-ai.vercel.app

---

## 📜 الرخصة

MIT License - 2026

---

<p align="center">
  <b>🏇 HorseMaster - ترشيحات ذكية لسباقات الخيل 🏇</b>
</p>
