# 🏇 Horse AI Predictor

نظام الذكاء الاصطناعي لترشيحات سباقات الخيل مع دعم المراهنات والتعلم الذاتي.

## ✨ المميزات

- 🌍 دعم مضامير الإمارات وبريطانيا
- 📊 تحليل متقدم بـ 7 عوامل رئيسية
- 🧠 تعلم ذاتي من نتائج السباقات
- 💰 توصيات مراهنات (Balanced + Aggressive)
- 🌐 واجهة ويب سهلة الاستخدام

## 📦 التثبيت

### 1. تثبيت Python
```bash
# تحميل من python.org (الإصدار 3.10+)
```

### 2. تثبيت المتطلبات
```bash
pip install -r requirements.txt
```

### 3. تثبيت ChromeDriver
1. تحميل من: https://googlechromelabs.github.io/chrome-for-testing/
2. ضع الملف في: `C:\Users\Elghali Ali\chromedriver.exe`

## 🚀 التشغيل

### الطريقة 1: سطر الأوامر
```bash
python race_bot.py --track meydan --date 2026-02-18
```

### الطريقة 2: الوضع التفاعلي
```bash
python race_bot.py -i
```

### الطريقة 3: واجهة الويب
```bash
streamlit run app.py
```

## 📁 هيكل المشروع

```
horse_ai/
├── race_bot.py           # النظام الرئيسي
├── app.py               # واجهة الويب
├── requirements.txt     # المتطلبات
├── bots/
│   └── learning_engine.py  # محرك التعلم
├── data/               # قاعدة البيانات
└── output/             # النتائج
```

## 🧠 كيف يعمل النظام

### عوامل التحليل (مع الأوزان)

| العامل | الوزن | الوصف |
|--------|-------|-------|
| التقييم الرسمي | 25% | Rating |
| الفورمة الأخيرة | 20% | آخر 5 سباقات |
| الفارس | 15% | خبرة وأداء |
| المدرب | 15% | سجل الفوز |
| ملاءمة المسافة | 10% | المسافة |
| ملاءمة الأرضية | 10% | Dirt/Turf |
| بوابة الانطلاق | 5% | Draw |

### أنواع التوصيات

#### 🟢 رهان متوازن (Balanced)
- احتمال فوز 20%+
- مخاطرة منخفضة

#### 🟡 رهان عالي المخاطرة (Aggressive)
- احتمال فوز 15-20%
- عائد أعلى

## 📊 المضامير المدعومة

### الإمارات 🇦🇪
- Meydan Racecourse
- Jebel Ali Racecourse
- Al Ain Racecourse
- Abu Dhabi Equestrian Club
- Sharjah Equestrian

### بريطانيا 🇬🇧
- Wolverhampton
- Lingfield Park
- Kempton Park
- Newcastle

## 🔄 التعلم الذاتي

النظام يتعلم من كل سباق:
1. يسجل التوقعات
2. يقارن بالنتائج الفعلية
3. يعدل الأوزان تلقائياً
4. يحسن الدقة مع الوقت

## 📝 مثال الاستخدام

```python
from race_bot import HorseAIPredictor

predictor = HorseAIPredictor()
predictions = predictor.predict("meydan", "2026-02-18")

# عرض الترشيحات
predictor.display_predictions(predictions)
```

## ⚠️ تنبيه

هذا النظام للأغراض الترفيهية والتعليمية.
المراهنة تنطوي على مخاطر مالية.

## 📄 الرخصة

MIT License - © 2026 Horse AI Predictor
