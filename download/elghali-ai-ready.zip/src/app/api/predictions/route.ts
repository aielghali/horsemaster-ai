import { NextRequest, NextResponse } from 'next/server'

const HORSES = ['Desert Crown', 'Dubai Honor', 'Emirates Star', 'Golden Storm', 'Thunder Road', 'Lightning Bolt', 'Royal Command', 'Noble Victory']
const JOCKEYS = ['S. De Sousa', 'C. Soumillon', 'J. Rosario', 'A. De Vries']

export async function POST(request: NextRequest) {
  try {
    const { date, racecourse, email } = await request.json()
    if (!date || !racecourse || !email) {
      return NextResponse.json({ success: false, message: 'Required', racecourse: '', date: '', totalRaces: 0, predictions: [], napOfTheDay: { horseName: '', raceName: '', reason: '' }, nextBest: { horseName: '', raceName: '', reason: '' }, sources: [] }, { status: 400 })
    }

    const predictions = []
    for (let r = 1; r <= 6; r++) {
      predictions.push({
        raceNumber: r,
        raceName: `Race ${r}`,
        raceTime: `${17 + r}:00`,
        surface: r % 2 === 0 ? 'Dirt' : 'Turf',
        predictions: [1, 2, 3].map(pos => ({
          position: pos,
          horseName: HORSES[Math.floor(Math.random() * HORSES.length)],
          rating: String(70 + Math.floor(Math.random() * 30)),
          jockey: JOCKEYS[Math.floor(Math.random() * JOCKEYS.length)],
          winProbability: `${45 - pos * 10}%`,
          analysis: pos === 1 ? 'Top pick' : 'Good option'
        }))
      })
    }

    return NextResponse.json({
      success: true, racecourse, date, totalRaces: 6, predictions,
      napOfTheDay: { horseName: HORSES[0], raceName: 'Race 1', reason: 'Best prediction today' },
      nextBest: { horseName: HORSES[1], raceName: 'Race 2', reason: 'Second choice' },
      sources: ['racingpost.com']
    })
  } catch { return NextResponse.json({ success: false, message: 'Error' }, { status: 500 }) }
}
