'use client'

import { useState } from 'react'
import { format } from 'date-fns'
import { CalendarIcon, Loader2, Trophy, CheckCircle2, AlertCircle, Globe } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'

export default function Home() {
  const [lang, setLang] = useState<'ar' | 'en'>('ar')
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [racecourse, setRacecourse] = useState('')
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState('')

  const isArabic = lang === 'ar'

  const text = {
    title: 'Elghali Ai',
    subtitle: isArabic ? 'ترشيحات سباقات الخيل الذكية' : 'Smart Horse Racing Predictions',
    welcome: isArabic ? 'مرحباً بك' : 'Welcome',
    desc: isArabic ? 'نظام الذكاء الاصطناعي لتحليل سباقات الخيل' : 'AI Horse Racing Analysis',
    dateLabel: isArabic ? 'تاريخ السباق' : 'Race Date',
    raceLabel: isArabic ? 'اسم المضمار' : 'Racecourse',
    emailLabel: isArabic ? 'البريد الإلكتروني' : 'Email',
    start: isArabic ? 'بدء التحليل' : 'Start Analysis',
    processing: isArabic ? 'جاري المعالجة...' : 'Processing...',
    success: isArabic ? 'تم بنجاح!' : 'Success!',
    errorTitle: isArabic ? 'خطأ' : 'Error',
    nap: isArabic ? 'ترشيح اليوم' : 'NAP of the Day',
    races: isArabic ? 'سباقات' : 'Races'
  }

  const handleSubmit = async () => {
    if (!date || !racecourse || !email) {
      setError(isArabic ? 'جميع الحقول مطلوبة' : 'All fields required')
      return
    }
    setLoading(true); setError(''); setResult(null)
    try {
      const res = await fetch('/api/predictions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ date: format(date, 'yyyy-MM-dd'), racecourse: racecourse.trim(), email: email.trim() })
      })
      const data = await res.json()
      if (data.success) setResult(data)
      else setError(data.message || 'Error')
    } catch { setError(isArabic ? 'خطأ في الاتصال' : 'Connection error') }
    finally { setLoading(false) }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-red-50" dir={isArabic ? 'rtl' : 'ltr'}>
      <header className="bg-gradient-to-l from-red-900 via-red-800 to-red-900 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-amber-400 rounded-full flex items-center justify-center text-3xl">🐎</div>
            <div><h1 className="text-3xl font-bold text-amber-400">{text.title}</h1><p className="text-amber-200 text-sm">{text.subtitle}</p></div>
          </div>
          <Button variant="ghost" onClick={() => setLang(isArabic ? 'en' : 'ar')} className="text-amber-200"><Globe className="w-4 h-4 mr-2" />{isArabic ? 'English' : 'العربية'}</Button>
        </div>
      </header>
      <main className="container mx-auto px-4 py-8 max-w-2xl">
        <Card className="mb-6 border-amber-200"><CardContent className="pt-6"><h2 className="text-xl font-bold text-red-900 mb-2">{text.welcome}</h2><p className="text-gray-600">{text.desc}</p></CardContent></Card>
        <Card className="mb-6 shadow-lg border-amber-200">
          <CardHeader className="bg-gradient-to-l from-red-900 to-red-800 text-white rounded-t-lg"><CardTitle className="text-amber-400">{isArabic ? 'إدخال بيانات السباق' : 'Race Information'}</CardTitle></CardHeader>
          <CardContent className="p-6 space-y-5">
            <div><Label className="text-red-900 font-bold">{text.dateLabel}</Label><Popover><PopoverTrigger asChild><Button variant="outline" className="w-full justify-between mt-2">{date ? format(date, 'yyyy-MM-dd') : 'Select'}<CalendarIcon className="w-4 h-4" /></Button></PopoverTrigger><PopoverContent><Calendar mode="single" selected={date} onSelect={setDate} /></PopoverContent></Popover></div>
            <div><Label className="text-red-900 font-bold">{text.raceLabel}</Label><Input value={racecourse} onChange={e => setRacecourse(e.target.value)} placeholder="Meydan, Ascot..." className="mt-2" list="tracks" /><datalist id="tracks"><option value="Meydan" /><option value="Jebel Ali" /><option value="Abu Dhabi" /><option value="Ascot" /></datalist></div>
            <div><Label className="text-red-900 font-bold">{text.emailLabel}</Label><Input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="email@example.com" className="mt-2" dir="ltr" /></div>
            <Button onClick={handleSubmit} disabled={loading} className="w-full bg-red-800 text-white py-6 text-lg">{loading ? <><Loader2 className="w-5 h-5 animate-spin mr-2" />{text.processing}</> : <><Trophy className="w-5 h-5 mr-2" />{text.start}</>}</Button>
          </CardContent>
        </Card>
        {error && <Alert variant="destructive" className="mb-6"><AlertCircle className="w-4 h-4" /><AlertTitle>{text.errorTitle}</AlertTitle><AlertDescription>{error}</AlertDescription></Alert>}
        {result && (
          <Card className="mb-6 shadow-lg border-amber-200">
            <CardHeader className="bg-gradient-to-l from-red-900 to-red-800 text-white rounded-t-lg"><div className="flex items-center justify-between"><CardTitle className="text-amber-400 flex items-center gap-2"><CheckCircle2 className="w-5 h-5" />{text.success}</CardTitle><Badge className="bg-amber-400 text-red-900">{result.totalRaces} {text.races}</Badge></div><p className="text-amber-200 text-sm mt-1">{result.racecourse} - {result.date}</p></CardHeader>
            <CardContent className="p-6">
              <div className="mb-6 p-4 bg-amber-100 rounded-lg border-2 border-amber-300"><h3 className="font-bold text-red-900 text-lg">🌟 {text.nap}</h3><p className="text-2xl font-bold text-amber-700">{result.napOfTheDay?.horseName}</p><p className="text-gray-600 mt-1">{result.napOfTheDay?.reason}</p></div>
              <div className="space-y-4">{result.predictions?.map((race: any, i: number) => (<div key={i} className="border border-amber-200 rounded-lg"><div className="bg-amber-50 px-4 py-2 border-b flex justify-between"><span className="font-bold text-red-900">{race.raceName}</span><span className="text-sm text-gray-500">{race.raceTime}</span></div><div className="p-3 grid grid-cols-3 gap-3">{race.predictions?.map((h: any, j: number) => (<div key={j} className={cn("p-3 rounded-lg text-center", j === 0 && "bg-amber-100 border-2 border-amber-400", j === 1 && "bg-gray-100", j === 2 && "bg-orange-50")}><div className="font-bold text-red-900">{h.horseName}</div><div className="text-amber-600 font-medium">{h.winProbability}</div></div>))}</div></div>))}</div>
            </CardContent>
          </Card>
        )}
      </main>
      <footer className="bg-red-900 text-white py-4 mt-8"><div className="container mx-auto text-center"><p className="text-amber-200">© 2025 Elghali Ai</p></div></footer>
    </div>
  )
}
