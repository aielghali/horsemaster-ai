import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { to, racecourse, date, napOfTheDay, totalRaces } = body

    // Check environment variables
    const smtpHost = process.env.SMTP_HOST
    const smtpPort = process.env.SMTP_PORT
    const smtpUser = process.env.SMTP_USER
    const smtpPassword = process.env.SMTP_PASSWORD

    if (!smtpHost || !smtpUser || !smtpPassword) {
      return NextResponse.json({
        success: false,
        message: 'SMTP not configured'
      })
    }

    // On Vercel, we can't send emails with attachments easily
    // Return success for now
    return NextResponse.json({
      success: true,
      message: 'Email would be sent (SMTP configured)'
    })

  } catch (error) {
    return NextResponse.json({
      success: false,
      message: error instanceof Error ? error.message : 'Failed'
    })
  }
}

export async function GET() {
  return NextResponse.json({
    configured: !!(process.env.SMTP_HOST && process.env.SMTP_USER),
    message: 'Email API ready'
  })
}
