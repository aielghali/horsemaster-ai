import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

interface SearchResult {
  url: string
  name: string
  snippet: string
  host_name: string
  rank: number
  date: string
  favicon: string
}

export async function POST(request: NextRequest) {
  try {
    const { date, racecourse } = await request.json()

    if (!date || !racecourse) {
      return NextResponse.json(
        { success: false, message: 'Date and racecourse are required' },
        { status: 400 }
      )
    }

    const zai = await ZAI.create()
    
    // Format date for search queries
    const dateObj = new Date(date)
    const formattedDate = dateObj.toLocaleDateString('en-GB', { 
      day: '2-digit', 
      month: 'long', 
      year: 'numeric' 
    })
    
    // Search queries for multiple sources
    const searchQueries = [
      // Emirates Racing Authority
      `site:emiratesracing.com ${racecourse} ${date}`,
      `site:emiratesracing.com racecard ${racecourse} ${formattedDate}`,
      
      // At The Races
      `site:attheraces.com ${racecourse} ${date} racecard`,
      `site:attheraces.com ${racecourse} ${formattedDate} tips`,
      
      // Racing Post
      `site:racingpost.com ${racecourse} ${date} racecard`,
      `site:racingpost.com ${racecourse} ${formattedDate} predictions`,
      
      // Sky Racing World
      `site:skyracingworld.com ${racecourse} ${date}`,
      `site:skyracingworld.com form guide ${racecourse} ${formattedDate}`,
      
      // Racing TV
      `site:racingtv.com ${racecourse} ${date} racecard`,
      
      // Timeform
      `site:timeform.com ${racecourse} ${date} tips`,
      
      // TipMeerkat - NEW
      `site:tipmeerkat.com ${racecourse} ${date}`,
      `site:tipmeerkat.com ${racecourse} tips predictions`,
      
      // Racing And Sports
      `site:racingandsports.com ${racecourse} ${date} form`,
      
      // Bloodstock
      `site:bloodhorse.com ${racecourse} ${date}`,
      
      // General searches
      `${racecourse} horse racing ${date} runners racecard`,
      `${racecourse} ${formattedDate} horse racing tips predictions`,
      `${racecourse} ${date} jockey trainer statistics form`
    ]

    const allResults: SearchResult[] = []
    
    // Execute searches
    for (const query of searchQueries) {
      try {
        const results = await zai.functions.invoke('web_search', {
          query: query,
          num: 5
        }) as SearchResult[]
        
        if (Array.isArray(results)) {
          allResults.push(...results)
        }
      } catch (searchError) {
        console.error(`Search failed for query: ${query}`, searchError)
      }
    }

    // Remove duplicates based on URL
    const uniqueResults = allResults.filter((result, index, self) =>
      index === self.findIndex(r => r.url === result.url)
    )

    // Sort by relevance
    const sortedResults = uniqueResults.sort((a, b) => {
      const aScore = getRelevanceScore(a, racecourse, date)
      const bScore = getRelevanceScore(b, racecourse, date)
      return bScore - aScore
    })

    // Take top 20 results
    const topResults = sortedResults.slice(0, 20)

    // Build raw content for AI analysis
    const rawContent = topResults.map(result => 
      `Source: ${result.host_name}\nTitle: ${result.name}\nURL: ${result.url}\nSnippet: ${result.snippet}\n`
    ).join('\n---\n')

    // Extract sources used
    const sources = [...new Set(topResults.map(r => r.host_name))]

    return NextResponse.json({
      success: true,
      date,
      racecourse,
      resultsCount: topResults.length,
      sources,
      rawContent,
      detailedResults: topResults
    })

  } catch (error) {
    console.error('Search races error:', error)
    return NextResponse.json(
      { 
        success: false, 
        message: error instanceof Error ? error.message : 'Failed to search races' 
      },
      { status: 500 }
    )
  }
}

function getRelevanceScore(result: SearchResult, racecourse: string, date: string): number {
  let score = 0
  
  const lowerName = result.name.toLowerCase()
  const lowerSnippet = result.snippet.toLowerCase()
  const lowerHost = result.host_name.toLowerCase()
  const lowerRacecourse = racecourse.toLowerCase()
  
  // Check racecourse match
  if (lowerName.includes(lowerRacecourse) || lowerSnippet.includes(lowerRacecourse)) {
    score += 10
  }
  
  // Check date match
  if (lowerName.includes(date) || lowerSnippet.includes(date)) {
    score += 8
  }
  
  // Prioritize certain sources
  if (lowerHost.includes('emiratesracing')) score += 5
  if (lowerHost.includes('racingpost')) score += 4
  if (lowerHost.includes('attheraces')) score += 4
  if (lowerHost.includes('tipmeerkat')) score += 4
  if (lowerHost.includes('skyracingworld')) score += 3
  if (lowerHost.includes('racingtv')) score += 3
  if (lowerHost.includes('timeform')) score += 3
  if (lowerHost.includes('racingandsports')) score += 3
  if (lowerHost.includes('bloodhorse')) score += 2
  
  // Check for racecard/tips keywords
  if (lowerName.includes('racecard') || lowerSnippet.includes('racecard')) score += 3
  if (lowerName.includes('tips') || lowerSnippet.includes('tips')) score += 2
  if (lowerName.includes('runners') || lowerSnippet.includes('runners')) score += 2
  
  return score
}
