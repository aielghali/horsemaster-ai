import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { 
  getTrackProfile, 
  getDistanceProfile, 
  calculateTrackAdjustments,
  getTrackTipsArabic,
  TrackProfile 
} from '@/lib/track-profiles'

interface HorsePrediction {
  position: number
  horseNumber: number
  horseName: string
  gate: number
  jockey: string
  trainer: string
  owner: string
  rating: number
  weight: number
  winProbability: number
  jockeyWinRate: number
  trainerWinRate: number
  ownerForm: string
  tipmeerkatTip: string
  analysis: string
  isSurprise: boolean
  // معاملات جديدة بناءً على خصائص المضمار
  staminaScore?: number
  speedScore?: number
  accelerationScore?: number
  gateAdvantage?: string
  runningStyle?: string
  weightAdjustedProbability?: number
}

interface RacePrediction {
  raceNumber: number
  raceName: string
  raceNameAr: string
  distance: number
  surface: string
  classification: string
  raceTime: string
  predictions: HorsePrediction[]
  nonRunners: string[]
  // معلومات المضمار
  trackInfo?: {
    name: string
    nameAr: string
    direction: string
    homeStraight: number
    specialFeatures: string[]
  }
}

interface TrackAnalysisData {
  trackProfile: TrackProfile | null
  distanceType: string
  adjustments: {
    staminaRequired: number
    speedImportance: number
    accelerationImportance: number
    insideAdvantage: number
    frontRunningValue: number
    stalkingValue: number
    closersValue: number
    weightImpact: number
  }
  tips: string[]
}

export async function POST(request: NextRequest) {
  try {
    const { date, racecourse, searchData, sources, raceData } = await request.json()

    if (!date || !racecourse) {
      return NextResponse.json(
        { success: false, message: 'Date and racecourse are required' },
        { status: 400 }
      )
    }

    // الحصول على ملف تعريف المضمار
    const trackProfile = getTrackProfile(racecourse)
    
    // تحليل المضمار
    const trackAnalysis = analyzeTrackForRace(trackProfile, raceData)

    const zai = await ZAI.create()

    // إنشاء معلومات المضمار للـ prompt
    const trackInfoSection = trackProfile ? `
═══════════════════════════════════════════════════════════════
📍 معلومات المضمار: ${trackProfile.nameAr} (${trackProfile.name})
═══════════════════════════════════════════════════════════════
• الاتجاه: ${trackProfile.trackCharacteristics.directionAr} (${trackProfile.trackCharacteristics.direction})
• الشكل: ${trackProfile.trackCharacteristics.shapeAr}
• السطوح المتاحة: ${trackProfile.surfaces.map(s => `${s.typeAr} (${s.circumference}م)`).join(' | ')}
• خط النهاية: ${trackProfile.surfaces[0].homeStraight}م
• تأثير الوزن: ${trackProfile.weightImpact.overall}/10
• ميزة الانطلاقات الداخلية: ${trackProfile.positionAdvantages.insideAdvantage > 0 ? '+' : ''}${trackProfile.positionAdvantages.insideAdvantage}

🎯 متطلبات السباقات:
• السبرنت (1000-1300م): سرعة ${trackProfile.distanceFactors.sprint.speedImportance}/10 | تحمل ${trackProfile.distanceFactors.sprint.staminaRequired}/10
• الميل (1400-1700م): سرعة ${trackProfile.distanceFactors.mile.speedImportance}/10 | تحمل ${trackProfile.distanceFactors.mile.staminaRequired}/10
• المتوسط (1800-2100م): سرعة ${trackProfile.distanceFactors.middle.speedImportance}/10 | تحمل ${trackProfile.distanceFactors.middle.staminaRequired}/10
• الطويلة (2200م+): سرعة ${trackProfile.distanceFactors.long.speedImportance}/10 | تحمل ${trackProfile.distanceFactors.long.staminaRequired}/10

🏃 أساليب السباق المفضلة:
• المتقدمون (Front-runners): ${trackProfile.positionAdvantages.frontRunning}/10
• المتتبعون (Stalkers): ${trackProfile.positionAdvantages.stalking}/10
• المتأخرون (Closers): ${trackProfile.positionAdvantages.closers}/10

⚡ خصائص خاصة:
${trackProfile.specialFeatures.map(f => `• ${f.nameAr}: ${f.descriptionAr} [${f.impact === 'positive' ? 'إيجابي' : f.impact === 'negative' ? 'سلبي' : 'محايد'}]`).join('\n')}
═══════════════════════════════════════════════════════════════
` : ''

    // Create comprehensive AI prompt for analysis
    const systemPrompt = `أنت "Elghali Ai" - نموذج متخصص في تحليل سباقات الخيل وتقديم الترشيحات الاحترافية.

خبراتك:
- تحليل بيانات الخيل من مصادر متعددة
- تقييم تصنيفات الخيول (Rating)
- تحليل تنافس الفرسان (Jockey Statistics)
- تحليل أداء المدربين (Trainer Form)
- تقييم قوة الملاك (Owner Power)
- فهم تأثير السطح (Dirt/Turf) والمسافة والبوابة
- تحديد المفاجآت المحتملة (Dark Horses)
- تقديم ترشيحات دقيقة مع نسب الثقة
- **تحليل خصائص المضمار وتطبيقها على كل حصان**

المصادر الموثوقة:
- emiratesracing.com (البيانات الرسمية الإماراتية)
- attheraces.com (تحليلات وتوقعات)
- racingpost.com (إحصائيات شاملة)
- skyracingworld.com (دليل الأداء)
- racingtv.com (تغطية مباشرة)
- timeform.com (تصنيفات متخصصة)
- tipmeerkat.com (نصائح الخبراء)
- racingandsports.com (إحصائيات)
- bloodhorse.com (معلومات الملاك)

قواعد الترشيح المهمة:
1. ترشيح 5 خيول لسباقات الإمارات العربية المتحدة
2. ترشيح 3 خيول للسباقات خارج الإمارات
3. تحليل تنافس الفرسان: نسبة الفوز في المضمار، الخبرة
4. تحليل المدربين: معدل الفوز في الموسم، تاريخ في السباق
5. تحليل الملاك: Godolphin, Shadwell وغيرها
6. مراعاة البوابة: البوابات الداخلية أفضل في السبرنت (أو حسب خصائص المضمار)
7. مراعاة السطح: بعض الخيول متخصصة في الرملي أو العشبي
8. تحديد المفاجآت: خيول بتصنيف منخفض لكن لها فرصة
9. ذكر الخيول غير المشاركة (Non-Runners)
10. **تطبيق خصائص المضمار على كل حصان**

معاملات التحليل الخاصة بالمضمار:
- قوة التحمل (Stamina): حسب مسافة السباق وخصائص المضمار
- السرعة (Speed): أهميتها حسب المسافة
- التسارع (Acceleration): في آخر 400م
- ميزة البوابة (Gate Advantage): حسب خصائص المضمار
- أسلوب السباق (Running Style): متقدم/متتبع/متأخر
- تعديل الوزن: حسب تأثير الوزن في المضمار`

    const userPrompt = `قم بتحليل بيانات سباقات الخيل التالية وتقديم ترشيحات احترافية:

${trackInfoSection}

المضمار: ${racecourse}
التاريخ: ${date}
المصادر: ${sources?.join(', ') || 'متعددة'}

بيانات البحث:
${searchData || 'لا توجد بيانات متاحة'}

بيانات السباقات (من emiratesracing.com):
${raceData || 'لا توجد بيانات متاحة'}

المطلوب:
1. تحليل كل سباق متاح
2. ترشيح 5 خيول للسباقات في الإمارات، 3 للسباقات الخارجية
3. تحليل تنافس الفرسان والمدربين والملاك
4. **تطبيق خصائص المضمار على كل حصان**
5. تحديد المفاجآت المحتملة
6. ذكر الخيول غير المشاركة
7. تقديم تحليل مفصل لسبب الترشيح

أرجع النتيجة بصيغة JSON بالتنسيق التالي:
{
  "success": true,
  "racecourse": "اسم المضمار",
  "date": "التاريخ",
  "country": "UAE أو غيرها",
  "totalRaces": عدد السباقات,
  "trackProfile": {
    "name": "اسم المضمار",
    "nameAr": "اسم المضمار بالعربية",
    "direction": "اتجاه المضمار",
    "homeStraight": طول_خط_النهاية,
    "specialFeatures": ["الخصائص الخاصة"]
  },
  "predictions": [
    {
      "raceNumber": رقم السباق,
      "raceName": "اسم السباق بالإنجليزية",
      "raceNameAr": "اسم السباق بالعربية",
      "distance": المسافة_بالأمتار,
      "surface": "Dirt أو Turf",
      "classification": "تصنيف الخيول مثال: 50-75",
      "raceTime": "وقت السباق",
      "nonRunners": ["قائمة الخيول غير المشاركة"],
      "predictions": [
        {
          "position": المركز_1_2_3_4_5,
          "horseNumber": رقم_الحصان_في_التذكرة,
          "horseName": "اسم الحصان",
          "gate": رقم_البوابة,
          "jockey": "اسم الفارس",
          "trainer": "اسم المدرب",
          "owner": "اسم المالك",
          "rating": التصنيف,
          "weight": الوزن,
          "winProbability": نسبة_الفوز,
          "jockeyWinRate": "نسبة فوز الفارس في المضمار",
          "trainerWinRate": "نسبة فوز المدرب هذا الموسم",
          "ownerForm": "أداء المالك الأخير",
          "tipmeerkatTip": "نصيحة tipmeerkat",
          "analysis": "تحليل مفصل: لماذا تم اختيار هذا الحصان",
          "isSurprise": true_أو_false,
          "staminaScore": درجة_التحمل_من_1_إلى_10,
          "speedScore": درجة_السرعة_من_1_إلى_10,
          "accelerationScore": درجة_التسارع_من_1_إلى_10,
          "gateAdvantage": "عالية/متوسطة/منخفضة",
          "runningStyle": "متقدم/متتبع/متأخر",
          "weightAdjustedProbability": نسبة_الفوز_المعدلة_حسب_الوزن
        }
      ]
    }
  ],
  "napOfTheDay": {
    "horseName": "اسم الحصان",
    "raceNumber": رقم_السباق,
    "reason": "سبب اختياره كأفضل ترشيح"
  },
  "nextBest": {
    "horseName": "اسم الحصان",
    "raceNumber": رقم_السباق,
    "reason": "سبب الترشيح"
  },
  "surprises": [
    {
      "horseName": "اسم الحصان المفاجأة",
      "raceNumber": رقم_السباق,
      "reason": "سبب الترشيح كمفاجأة"
    }
  ],
  "topJockey": {
    "name": "اسم الفارس الأكثر تنافسية",
    "winRate": "نسبة الفوز",
    "horses": ["الخيول التي يركبها"]
  },
  "topTrainer": {
    "name": "اسم المدرب الأكثر تنافسية",
    "winRate": "نسبة الفوز",
    "horses": ["الخيول التي يدربها"]
  },
  "topOwner": {
    "name": "اسم المالك الأكثر تنافسية",
    "form": "أداء المالك",
    "horses": ["الخيول التي يملكها"]
  }
}

إذا لم تكن البيانات كافية، قم بإنشاء بيانات واقعية بناءً على:
- أنماط السباقات الشائعة في المضمار المحدد
- الفرسان والمدربين المعروفين في المنطقة
- الملاك المشهورين مثل Godolphin, Shadwell
- التصنيفات المناسبة للسباق
- **خصائص المضمار المذكورة أعلاه**`

    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      thinking: { type: 'disabled' }
    })

    const aiResponse = completion.choices[0]?.message?.content || ''

    // Try to extract JSON from the response
    let analysisResult
    try {
      // Find JSON in the response
      const jsonMatch = aiResponse.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        analysisResult = JSON.parse(jsonMatch[0])
      } else {
        throw new Error('No JSON found in AI response')
      }
    } catch (parseError) {
      console.error('Failed to parse AI response as JSON:', parseError)
      
      // Create default structure
      analysisResult = {
        success: true,
        racecourse,
        date,
        country: 'UAE',
        totalRaces: 1,
        predictions: createDefaultPredictions(racecourse, trackProfile),
        napOfTheDay: {
          horseName: 'Top Contender',
          raceNumber: 1,
          reason: 'Best form and conditions'
        },
        nextBest: {
          horseName: 'Strong Challenger',
          raceNumber: 1,
          reason: 'Good each-way value'
        }
      }
    }

    // تطبيق تعديلات المضمار على الترشيحات
    if (trackProfile && analysisResult.predictions) {
      analysisResult.predictions = analysisResult.predictions.map((race: RacePrediction) => {
        const distance = race.distance || 1600
        const distanceProfile = getDistanceProfile(trackProfile, distance)
        const adjustments = calculateTrackAdjustments(trackProfile, distance)
        
        return {
          ...race,
          trackInfo: {
            name: trackProfile.name,
            nameAr: trackProfile.nameAr,
            direction: trackProfile.trackCharacteristics.directionAr,
            homeStraight: trackProfile.surfaces[0].homeStraight,
            specialFeatures: trackProfile.specialFeatures.slice(0, 3).map(f => f.nameAr)
          },
          predictions: race.predictions?.map((horse: HorsePrediction) => ({
            ...horse,
            staminaScore: horse.staminaScore || adjustForStamina(horse, adjustments.staminaRequired),
            speedScore: horse.speedScore || adjustForSpeed(horse, adjustments.speedImportance),
            accelerationScore: horse.accelerationScore || adjustForAcceleration(horse, adjustments.accelerationImportance),
            gateAdvantage: horse.gateAdvantage || getGateAdvantage(horse.gate, adjustments.insideAdvantage),
            runningStyle: horse.runningStyle || determineRunningStyle(horse, adjustments),
            weightAdjustedProbability: horse.weightAdjustedProbability || adjustForWeight(horse, adjustments.weightImpact)
          })) || []
        }
      })
    }

    // Ensure all required fields exist
    const result = {
      success: true,
      racecourse: analysisResult.racecourse || racecourse,
      date: analysisResult.date || date,
      country: analysisResult.country || 'UAE',
      totalRaces: analysisResult.totalRaces || analysisResult.predictions?.length || 1,
      trackProfile: trackProfile ? {
        id: trackProfile.id,
        name: trackProfile.name,
        nameAr: trackProfile.nameAr,
        location: trackProfile.locationAr,
        surfaces: trackProfile.surfaces.map(s => ({
          type: s.type,
          typeAr: s.typeAr,
          circumference: s.circumference
        })),
        direction: trackProfile.trackCharacteristics.directionAr,
        specialFeatures: trackProfile.specialFeatures.slice(0, 5).map(f => ({
          name: f.name,
          nameAr: f.nameAr,
          impact: f.impact
        }))
      } : null,
      predictions: analysisResult.predictions || [],
      napOfTheDay: analysisResult.napOfTheDay || null,
      nextBest: analysisResult.nextBest || null,
      surprises: analysisResult.surprises || [],
      topJockey: analysisResult.topJockey || null,
      topTrainer: analysisResult.topTrainer || null,
      topOwner: analysisResult.topOwner || null,
      sources: sources || [],
      rawAiResponse: aiResponse
    }

    return NextResponse.json(result)

  } catch (error) {
    console.error('Analyze error:', error)
    return NextResponse.json(
      { 
        success: false, 
        message: error instanceof Error ? error.message : 'Failed to analyze race data' 
      },
      { status: 500 }
    )
  }
}

// دوال مساعدة لتحليل المضمار

function analyzeTrackForRace(trackProfile: TrackProfile | null, raceData: any): TrackAnalysisData | null {
  if (!trackProfile) return null
  
  const distance = raceData?.distance || 1600
  const distanceProfile = getDistanceProfile(trackProfile, distance)
  const adjustments = calculateTrackAdjustments(trackProfile, distance)
  const tips = getTrackTipsArabic(trackProfile.name, distance)
  
  return {
    trackProfile,
    distanceType: distanceProfile.type,
    adjustments,
    tips
  }
}

function adjustForStamina(horse: HorsePrediction, staminaRequired: number): number {
  // حساب درجة التحمل بناءً على التصنيف والوزن والمسافة
  const baseScore = Math.min(10, Math.max(1, (horse.rating || 70) / 10))
  const weightAdjustment = (horse.weight || 58) > 60 ? -1 : (horse.weight || 58) < 56 ? 1 : 0
  return Math.min(10, Math.max(1, baseScore + weightAdjustment - (staminaRequired > 7 ? 1 : 0)))
}

function adjustForSpeed(horse: HorsePrediction, speedImportance: number): number {
  // حساب درجة السرعة بناءً على التصنيف والبوابة
  const baseScore = Math.min(10, Math.max(1, (horse.rating || 70) / 10))
  const gateBonus = horse.gate && horse.gate <= 4 ? 1 : 0
  return Math.min(10, Math.max(1, baseScore + gateBonus))
}

function adjustForAcceleration(horse: HorsePrediction, accelerationImportance: number): number {
  // حساب درجة التسارع
  const baseScore = Math.min(10, Math.max(1, (horse.rating || 70) / 10))
  return Math.min(10, Math.max(1, baseScore))
}

function getGateAdvantage(gate: number, insideAdvantage: number): string {
  if (insideAdvantage >= 3) {
    if (gate <= 4) return 'عالية جداً'
    if (gate <= 8) return 'عالية'
    if (gate <= 12) return 'متوسطة'
    return 'منخفضة'
  } else if (insideAdvantage <= -2) {
    if (gate <= 4) return 'متوسطة'
    if (gate <= 8) return 'عالية'
    return 'عالية جداً'
  }
  if (gate <= 6) return 'عالية'
  if (gate <= 12) return 'متوسطة'
  return 'منخفضة'
}

function determineRunningStyle(horse: HorsePrediction, adjustments: any): string {
  // تحديد أسلوب السباق بناءً على معاملات المضمار
  if (adjustments.frontRunningValue >= 8) return 'متقدم'
  if (adjustments.closersValue >= 8) return 'متأخر'
  return 'متتبع'
}

function adjustForWeight(horse: HorsePrediction, weightImpact: number): number {
  // تعديل نسبة الفوز بناءً على الوزن وتأثيره
  const baseProb = horse.winProbability || 20
  const weightAdjustment = ((horse.weight || 58) - 57) * (weightImpact / 20)
  return Math.max(1, Math.min(99, baseProb - weightAdjustment))
}

function createDefaultPredictions(racecourse: string, trackProfile: TrackProfile | null): RacePrediction[] {
  const distance = 1600
  const adjustments = trackProfile ? calculateTrackAdjustments(trackProfile, distance) : null
  
  return [
    {
      raceNumber: 1,
      raceName: 'Main Race',
      raceNameAr: 'السباق الرئيسي',
      distance: distance,
      surface: 'Dirt',
      classification: 'Handicap',
      raceTime: '18:00',
      nonRunners: [],
      trackInfo: trackProfile ? {
        name: trackProfile.name,
        nameAr: trackProfile.nameAr,
        direction: trackProfile.trackCharacteristics.directionAr,
        homeStraight: trackProfile.surfaces[0].homeStraight,
        specialFeatures: trackProfile.specialFeatures.slice(0, 3).map(f => f.nameAr)
      } : undefined,
      predictions: [
        {
          position: 1,
          horseNumber: 1,
          horseName: 'Top Contender',
          gate: 1,
          jockey: 'S. De Sousa',
          trainer: 'S. bin Suroor',
          owner: 'Godolphin',
          rating: 95,
          weight: 58.5,
          winProbability: 35,
          jockeyWinRate: 18,
          trainerWinRate: 22,
          ownerForm: 'Excellent',
          tipmeerkatTip: 'Top Pick',
          analysis: 'Leading candidate based on form and rating',
          isSurprise: false,
          staminaScore: adjustments ? adjustForStamina({ rating: 95, weight: 58.5 } as HorsePrediction, adjustments.staminaRequired) : 8,
          speedScore: adjustments ? adjustForSpeed({ rating: 95, gate: 1 } as HorsePrediction, adjustments.speedImportance) : 9,
          accelerationScore: 8,
          gateAdvantage: adjustments ? getGateAdvantage(1, adjustments.insideAdvantage) : 'عالية',
          runningStyle: 'متتبع',
          weightAdjustedProbability: 33
        }
      ]
    }
  ]
}
