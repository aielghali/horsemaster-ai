import { NextRequest, NextResponse } from 'next/server'
import { exec } from 'child_process'
import { promisify } from 'util'
import path from 'path'
import fs from 'fs'

const execAsync = promisify(exec)

interface Prediction {
  position: number
  horseName: string
  rating: string
  jockey: string
  winProbability: string
  analysis: string
}

interface RaceData {
  raceNumber: number
  raceName: string
  raceTime: string
  surface: string
  predictions: Prediction[]
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const { racecourse, date, totalRaces, predictions, napOfTheDay, nextBest } = data

    if (!racecourse || !date) {
      return NextResponse.json(
        { success: false, message: 'Racecourse and date are required' },
        { status: 400 }
      )
    }

    // Create Python script for PDF generation
    const pythonScript = generatePythonScript(data)
    
    // Save the script
    const scriptPath = path.join('/tmp', `generate_report_${Date.now()}.py`)
    fs.writeFileSync(scriptPath, pythonScript)

    // Generate PDF filename
    const pdfFilename = `Elghali_Ai_${racecourse.replace(/\s+/g, '_')}_${date.replace(/-/g, '')}.pdf`
    const pdfPath = path.join('/home/z/my-project/download', pdfFilename)

    // Execute the Python script
    try {
      await execAsync(`python3 "${scriptPath}"`, { timeout: 60000 })
    } catch (execError) {
      console.error('Python execution error:', execError)
      // Try with alternative Python path
      await execAsync(`python "${scriptPath}"`, { timeout: 60000 })
    }

    // Check if PDF was created
    if (fs.existsSync(pdfPath)) {
      // Add Z.ai metadata
      try {
        await execAsync(`python3 /home/z/my-project/skills/pdf/scripts/add_zai_metadata.py "${pdfPath}"`)
      } catch (metadataError) {
        console.error('Metadata error:', metadataError)
      }

      return NextResponse.json({
        success: true,
        pdfPath: `/download/${pdfFilename}`,
        absolutePath: pdfPath,
        filename: pdfFilename
      })
    } else {
      throw new Error('PDF file was not created')
    }

  } catch (error) {
    console.error('Generate report error:', error)
    return NextResponse.json(
      { 
        success: false, 
        message: error instanceof Error ? error.message : 'Failed to generate PDF report' 
      },
      { status: 500 }
    )
  }
}

function escapeStr(str: string): string {
  return str?.replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/"/g, '\\"').replace(/\n/g, '\\n') || ''
}

function generatePythonScript(data: any): string {
  const { racecourse, date, totalRaces, predictions, napOfTheDay, nextBest } = data
  
  return `
# -*- coding: utf-8 -*-
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.lib.units import cm
import arabic_reshaper
from bidi.algorithm import get_display
import json

def reshape_arabic(text):
    try:
        reshaped_text = arabic_reshaper.reshape(str(text))
        bidi_text = get_display(reshaped_text)
        return bidi_text
    except:
        return str(text)

# Register fonts
pdfmetrics.registerFont(TTFont('DejaVuSans', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuSans-Bold', '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
registerFontFamily('DejaVuSans', normal='DejaVuSans', bold='DejaVuSans-Bold')

# Create document
pdf_path = '/home/z/my-project/download/${escapeStr(`Elghali_Ai_${racecourse.replace(/\s+/g, '_')}_${date.replace(/-/g, '')}.pdf`)}'
doc = SimpleDocTemplate(
    pdf_path,
    pagesize=A4,
    rightMargin=1.5*cm,
    leftMargin=1.5*cm,
    topMargin=1.5*cm,
    bottomMargin=1.5*cm,
    title='${escapeStr(`Elghali Ai ${racecourse} ${date}`)}',
    author='Z.ai',
    creator='Z.ai'
)

# Styles
title_style = ParagraphStyle('Title', fontName='DejaVuSans-Bold', fontSize=24, leading=32, alignment=TA_CENTER, textColor=colors.HexColor('#8B0000'), spaceAfter=15)
subtitle_style = ParagraphStyle('Subtitle', fontName='DejaVuSans', fontSize=12, leading=18, alignment=TA_CENTER, textColor=colors.HexColor('#4A4A4A'), spaceAfter=10)
heading_style = ParagraphStyle('Heading', fontName='DejaVuSans-Bold', fontSize=12, leading=18, alignment=TA_LEFT, textColor=colors.HexColor('#8B0000'), spaceBefore=12, spaceAfter=6)
body_style = ParagraphStyle('Body', fontName='DejaVuSans', fontSize=9, leading=14, alignment=TA_LEFT, textColor=colors.black, spaceBefore=3, spaceAfter=3)
cell_style = ParagraphStyle('Cell', fontName='DejaVuSans', fontSize=8, leading=11, alignment=TA_CENTER, textColor=colors.black)
header_style = ParagraphStyle('Header', fontName='DejaVuSans-Bold', fontSize=9, leading=12, alignment=TA_CENTER, textColor=colors.white)
nap_style = ParagraphStyle('NAP', fontName='DejaVuSans-Bold', fontSize=14, leading=20, alignment=TA_CENTER, textColor=colors.white, spaceBefore=10, spaceAfter=10)

story = []

# Cover Page
story.append(Spacer(1, 40))
story.append(Paragraph('<b>Elghali Ai</b>', title_style))
story.append(Paragraph(reshape_arabic('<b>تقرير ترشيحات سباقات الخيل</b>'), subtitle_style))
story.append(Spacer(1, 15))
story.append(Paragraph('${escapeStr(racecourse)}', subtitle_style))
story.append(Paragraph('${escapeStr(date)}', subtitle_style))
story.append(Spacer(1, 20))
story.append(Paragraph(reshape_arabic('إجمالي السباقات: ${totalRaces || 0}'), body_style))
story.append(PageBreak())

# Predictions data
predictions_json = '''${escapeStr(JSON.stringify(predictions || []))}'''
predictions_data = json.loads(predictions_json)

nap_json = '''${escapeStr(JSON.stringify(napOfTheDay || {}))}'''
nap_data = json.loads(nap_json)

next_best_json = '''${escapeStr(JSON.stringify(nextBest || {}))}'''
next_best_data = json.loads(next_best_json)

# Summary Table
story.append(Paragraph('<b>' + reshape_arabic('ملخص الترشيحات') + '</b>', heading_style))
story.append(Spacer(1, 10))

if predictions_data:
    all_races_header = [
        Paragraph('<b>#</b>', header_style),
        Paragraph('<b>' + reshape_arabic('الوقت') + '</b>', header_style),
        Paragraph('<b>' + reshape_arabic('السباق') + '</b>', header_style),
        Paragraph('<b>' + reshape_arabic('الأول') + '</b>', header_style),
        Paragraph('<b>' + reshape_arabic('الثاني') + '</b>', header_style),
        Paragraph('<b>' + reshape_arabic('الثالث') + '</b>', header_style),
    ]
    
    all_races_data = [all_races_header]
    
    for race in predictions_data:
        preds = race.get('predictions', [])
        row = [
            Paragraph(str(race.get('raceNumber', '')), cell_style),
            Paragraph(str(race.get('raceTime', '')), cell_style),
            Paragraph(str(race.get('raceName', ''))[:20], cell_style),
            Paragraph(str(preds[0].get('horseName', '')) if len(preds) > 0 else '-', cell_style),
            Paragraph(str(preds[1].get('horseName', '')) if len(preds) > 1 else '-', cell_style),
            Paragraph(str(preds[2].get('horseName', '')) if len(preds) > 2 else '-', cell_style),
        ]
        all_races_data.append(row)
    
    all_table = Table(all_races_data, colWidths=[25, 45, 100, 80, 70, 60])
    all_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#8B0000')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    story.append(all_table)
    story.append(Spacer(1, 20))

# NAP Section
nap_horse = nap_data.get('horseName', 'N/A')
nap_race = nap_data.get('raceName', '')
nap_reason = nap_data.get('reason', '')

nap_box = Table([
    [Paragraph('<b>' + reshape_arabic('🌟 NAP of the Day: ${nap_horse} 🌟') + '</b>', nap_style)],
    [Paragraph(reshape_arabic('${nap_race}'), cell_style)],
    [Paragraph(reshape_arabic('${nap_reason}'), cell_style)],
], colWidths=[380])
nap_box.setStyle(TableStyle([
    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#006400')),
    ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#E8F5E9')),
    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
    ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ('TOPPADDING', (0, 0), (-1, -1), 8),
    ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
    ('BOX', (0, 0), (-1, -1), 2, colors.HexColor('#006400')),
]))
story.append(nap_box)
story.append(Spacer(1, 10))

# Next Best
next_horse = next_best_data.get('horseName', 'N/A')
next_race = next_best_data.get('raceName', '')

next_box = Table([
    [Paragraph('<b>' + reshape_arabic('Next Best: ${next_horse}') + '</b>', nap_style)],
    [Paragraph(reshape_arabic('${next_race}'), cell_style)],
], colWidths=[380])
next_box.setStyle(TableStyle([
    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1565C0')),
    ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#E3F2FD')),
    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
    ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ('TOPPADDING', (0, 0), (-1, -1), 8),
    ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
    ('BOX', (0, 0), (-1, -1), 2, colors.HexColor('#1565C0')),
]))
story.append(next_box)
story.append(PageBreak())

# Detailed Races
for race in predictions_data:
    race_num = race.get('raceNumber', '')
    race_name = race.get('raceName', '')
    race_time = race.get('raceTime', '')
    surface = race.get('surface', '')
    preds = race.get('predictions', [])
    
    story.append(Paragraph('<b>' + reshape_arabic('السباق ${race_num} (${race_time})') + '</b>', heading_style))
    story.append(Paragraph('${race_name} - ${surface}', body_style))
    story.append(Spacer(1, 5))
    
    race_table_data = [
        [Paragraph('<b>' + reshape_arabic('المركز') + '</b>', header_style),
         Paragraph('<b>' + reshape_arabic('الحصان') + '</b>', header_style),
         Paragraph('<b>Rating</b>', header_style),
         Paragraph('<b>Jockey</b>', header_style),
         Paragraph('<b>%</b>', header_style)]
    ]
    
    for i, pred in enumerate(preds[:3]):
        pos_emoji = ['', '', ''][i] if i < 3 else ''
        race_table_data.append([
            Paragraph(reshape_arabic(pos_emoji + ' ' + str(pred.get('position', i+1))), cell_style),
            Paragraph(str(pred.get('horseName', '')), cell_style),
            Paragraph(str(pred.get('rating', '-')), cell_style),
            Paragraph(str(pred.get('jockey', '-')), cell_style),
            Paragraph(str(pred.get('winProbability', '-')), cell_style)
        ])
    
    t = Table(race_table_data, colWidths=[60, 140, 50, 100, 40])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2E75B6')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('BACKGROUND', (0, 1), (-1, 1), colors.HexColor('#FFD700')),
        ('BACKGROUND', (0, 2), (-1, 2), colors.HexColor('#C0C0C0')),
        ('BACKGROUND', (0, 3), (-1, 3), colors.HexColor('#CD7F32')),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(t)
    story.append(Spacer(1, 10))

# Notes
story.append(Spacer(1, 15))
story.append(Paragraph('<b>' + reshape_arabic('ملاحظات مهمة') + '</b>', heading_style))
notes = [
    reshape_arabic('هذه الترشيحات مبنية على تحليل نموذج Elghali Ai.'),
    reshape_arabic('المصادر: emiratesracing.com, attheraces.com, racingpost.com, skyracingworld.com'),
    reshape_arabic('المراهنة تنطوي على مخاطر - الرجاء المراهنة بمسؤولية.'),
]
for note in notes:
    story.append(Paragraph('• ' + note, body_style))

# Build PDF
doc.build(story)
print(f"PDF created: {pdf_path}")
`
}
