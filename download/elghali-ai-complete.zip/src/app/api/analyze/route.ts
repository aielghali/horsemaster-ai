import { NextRequest, NextResponse } from 'next/server'
import { 
  getTrackProfile, 
  getDistanceProfile, 
  calculateTrackAdjustments,
  TrackProfile 
} from '@/lib/track-profiles'

interface HorsePrediction {
  position: number
  horseNumber: number
  horseName: string
  gate: number
  jockey: string
  trainer: string
  owner: string
  rating: number
  weight: number
  winProbability: number
  jockeyWinRate: number
  trainerWinRate: number
  ownerForm: string
  tipmeerkatTip: string
  analysis: string
  isSurprise: boolean
  staminaScore?: number
  speedScore?: number
  accelerationScore?: number
  gateAdvantage?: string
  runningStyle?: string
  weightAdjustedProbability?: number
}

interface RacePrediction {
  raceNumber: number
  raceName: string
  raceNameAr: string
  distance: number
  surface: string
  classification: string
  raceTime: string
  predictions: HorsePrediction[]
  nonRunners: string[]
  trackInfo?: {
    name: string
    nameAr: string
    direction: string
    homeStraight: number
    specialFeatures: string[]
  }
}

// Famous jockeys by region
const jockeysByRegion: Record<string, string[]> = {
  'UAE': ['S. De Sousa', 'C. Soumillon', 'J. Rosario', 'A. De Vries', 'R. Mullen', 'P. Dobbs', 'T. O\'Shea', 'A. Fresu'],
  'UK': ['R. Moore', 'L. Dettori', 'W. Buick', 'J. Spencer', 'O. Murphy', 'T. Marquand', 'W. Carson'],
  'US': ['I. Ortiz Jr', 'J. Velazquez', 'F. Geroux', 'J. Rosario', 'L. Saez', 'T. Gaffalione']
}

// Famous trainers by region
const trainersByRegion: Record<string, string[]> = {
  'UAE': ['S. bin Suroor', 'A. bin Suroor', 'M. Al Mheiri', 'D. Watson', 'M. Mussabeh', 'A. Al Rayhi'],
  'UK': ['A. O\'Brien', 'J. Gosden', 'W. Haggas', 'A. Balding', 'R. Hannon'],
  'US': ['B. Baffert', 'S. Asmussen', 'C. Brown', 'T. Pletcher', 'D. Cox']
}

// Famous owners
const owners = ['Godolphin', 'Shadwell', 'Meydan Racing', 'Sheikh Hamdan', 'Sheikh Mohammed', 'Juddmonte', 'Coolmore']

// Horse names generator
const horseNames = [
  'Desert Crown', 'Dubai Honor', 'Emirates Star', 'Golden Storm', 'Rapid Response',
  'Thunder Road', 'Lightning Bolt', 'Royal Command', 'Noble Victory', 'Swift Justice',
  'Desert Wind', 'Golden Arrow', 'Silver Storm', 'Night Rider', 'Morning Glory',
  'True Legend', 'Bold Move', 'Quick Silver', 'Desert King', 'Royal Crown',
  'Star Quality', 'High Hopes', 'Dream Maker', 'Lucky Charm', 'Fast Lane'
]

function getCountry(racecourse: string): string {
  const lowerRacecourse = racecourse.toLowerCase()
  if (['meydan', 'abu dhabi', 'al ain', 'jebel ali', 'sharjah'].some(r => lowerRacecourse.includes(r))) {
    return 'UAE'
  }
  if (['ascot', 'newmarket', 'epsom', 'york', 'doncaster', 'cheltenham'].some(r => lowerRacecourse.includes(r))) {
    return 'UK'
  }
  return 'US'
}

function generateHorseName(): string {
  return horseNames[Math.floor(Math.random() * horseNames.length)]
}

function generatePredictions(racecourse: string, date: string, trackProfile: TrackProfile | null): RacePrediction[] {
  const country = getCountry(racecourse)
  const jockeys = jockeysByRegion[country] || jockeysByRegion['UAE']
  const trainers = trainersByRegion[country] || trainersByRegion['UAE']
  
  const numRaces = country === 'UAE' ? 6 : 4
  const races: RacePrediction[] = []
  
  for (let r = 1; r <= numRaces; r++) {
    const distance = 1200 + (r * 200) + Math.floor(Math.random() * 200)
    const adjustments = trackProfile ? calculateTrackAdjustments(trackProfile, distance) : null
    
    const numHorses = country === 'UAE' ? 5 : 3
    const horses: HorsePrediction[] = []
    const usedNames = new Set<string>()
    
    for (let h = 1; h <= numHorses; h++) {
      let horseName = generateHorseName()
      while (usedNames.has(horseName)) {
        horseName = generateHorseName()
      }
      usedNames.add(horseName)
      
      const gate = Math.floor(Math.random() * 12) + 1
      const rating = 70 + Math.floor(Math.random() * 30)
      const weight = 54 + Math.floor(Math.random() * 8)
      const winProbability = Math.floor((100 - h * 10) + Math.random() * 10)
      
      const staminaScore = adjustments ? adjustForStamina(rating, weight, adjustments.staminaRequired) : 7
      const speedScore = adjustments ? adjustForSpeed(rating, gate, adjustments.speedImportance) : 7
      const accelerationScore = 6 + Math.floor(Math.random() * 4)
      const gateAdvantage = adjustments ? getGateAdvantage(gate, adjustments.insideAdvantage) : 'متوسطة'
      
      horses.push({
        position: h,
        horseNumber: Math.floor(Math.random() * 14) + 1,
        horseName,
        gate,
        jockey: jockeys[Math.floor(Math.random() * jockeys.length)],
        trainer: trainers[Math.floor(Math.random() * trainers.length)],
        owner: owners[Math.floor(Math.random() * owners.length)],
        rating,
        weight,
        winProbability,
        jockeyWinRate: 12 + Math.floor(Math.random() * 15),
        trainerWinRate: 15 + Math.floor(Math.random() * 15),
        ownerForm: ['ممتاز', 'جيد جداً', 'جيد'][Math.floor(Math.random() * 3)],
        tipmeerkatTip: h === 1 ? 'Top Pick' : h === 2 ? 'Value Bet' : 'Each Way',
        analysis: generateAnalysis(horseName, h, rating, gate, distance),
        isSurprise: h >= 4 && Math.random() > 0.5,
        staminaScore,
        speedScore,
        accelerationScore,
        gateAdvantage,
        runningStyle: ['متقدم', 'متتبع', 'متأخر'][Math.floor(Math.random() * 3)],
        weightAdjustedProbability: Math.max(5, winProbability - (weight > 58 ? 3 : weight < 56 ? 2 : 0))
      })
    }
    
    const raceNames = [
      { en: 'Maiden Stakes', ar: 'سباق الميدن' },
      { en: 'Handicap', ar: 'سباق الهانديكاب' },
      { en: 'Group 3', ar: 'المجموعة الثالثة' },
      { en: 'Group 2', ar: 'المجموعة الثانية' },
      { en: 'Group 1', ar: 'المجموعة الأولى' },
      { en: 'Feature Race', ar: 'السباق الرئيسي' }
    ]
    
    const race = raceNames[Math.min(r - 1, raceNames.length - 1)]
    
    races.push({
      raceNumber: r,
      raceName: race.en,
      raceNameAr: race.ar,
      distance,
      surface: r % 2 === 0 ? 'Dirt' : 'Turf',
      classification: `${50 + r * 5}-${70 + r * 5}`,
      raceTime: `${17 + r}:00`,
      nonRunners: [],
      trackInfo: trackProfile ? {
        name: trackProfile.name,
        nameAr: trackProfile.nameAr,
        direction: trackProfile.trackCharacteristics.directionAr,
        homeStraight: trackProfile.surfaces[0].homeStraight,
        specialFeatures: trackProfile.specialFeatures.slice(0, 3).map(f => f.nameAr)
      } : undefined,
      predictions: horses
    })
  }
  
  return races
}

function generateAnalysis(horseName: string, position: number, rating: number, gate: number, distance: number): string {
  const analyses = [
    `${horseName} يظهر شكلاً ممتازاً في التدريبات الأخيرة ومعدل تصنيف ${rating} يجعله مرشحاً قوياً`,
    `البوابة ${gate} مثالية لهذا الحصان، مع إمكانية التقدم المبكر في السباق`,
    `المسافة ${distance}م تناسب أسلوبه في السباق، ويتوقع له أداء قوي`,
    `الفارس والمدرب يعرفان كيفية إدارة السباق بشكل مثالي`
  ]
  
  if (position === 1) {
    return `${horseName} يتميز بأعلى تصنيف في السباق (${rating})، وأداء قوي في السباقات الأخيرة. البوابة ${gate} تعطيه ميزة إضافية. المرشح الأوفر حظاً للفوز.`
  } else if (position === 2) {
    return `${horseName} يملك فرصة جيدة مع تصنيف ${rating}. قد يكون خياراً جيداً للمراهنة المزدوجة.`
  } else if (position === 3) {
    return `${horseName} يستحق المتابعة، خاصة إذا كانت ظروف السباق في صالحه.`
  } else {
    return `${horseName} قد يكون مفاجأة السباق إذا سارت الأمور لصالحه.`
  }
}

function adjustForStamina(rating: number, weight: number, staminaRequired: number): number {
  const baseScore = Math.min(10, Math.max(1, rating / 10))
  const weightAdjustment = weight > 60 ? -1 : weight < 56 ? 1 : 0
  return Math.min(10, Math.max(1, Math.round(baseScore + weightAdjustment - (staminaRequired > 7 ? 1 : 0))))
}

function adjustForSpeed(rating: number, gate: number, speedImportance: number): number {
  const baseScore = Math.min(10, Math.max(1, rating / 10))
  const gateBonus = gate <= 4 ? 1 : 0
  return Math.min(10, Math.max(1, Math.round(baseScore + gateBonus)))
}

function getGateAdvantage(gate: number, insideAdvantage: number): string {
  if (insideAdvantage >= 3) {
    if (gate <= 4) return 'عالية جداً'
    if (gate <= 8) return 'عالية'
    if (gate <= 12) return 'متوسطة'
    return 'منخفضة'
  } else if (insideAdvantage <= -2) {
    if (gate <= 4) return 'متوسطة'
    if (gate <= 8) return 'عالية'
    return 'عالية جداً'
  }
  if (gate <= 6) return 'عالية'
  if (gate <= 12) return 'متوسطة'
  return 'منخفضة'
}

export async function POST(request: NextRequest) {
  try {
    const { date, racecourse, searchData, sources, raceData } = await request.json()

    if (!date || !racecourse) {
      return NextResponse.json(
        { success: false, message: 'Date and racecourse are required' },
        { status: 400 }
      )
    }

    const trackProfile = getTrackProfile(racecourse)
    const country = getCountry(racecourse)
    const predictions = generatePredictions(racecourse, date, trackProfile)
    
    // Find nap of the day (best prediction from all races)
    const allHorses = predictions.flatMap(r => r.predictions.map(h => ({ ...h, raceNumber: r.raceNumber })))
    const topHorse = allHorses.find(h => h.position === 1)
    const secondHorse = allHorses.find(h => h.position === 2)
    
    const napOfTheDay = topHorse ? {
      horseName: topHorse.horseName,
      raceNumber: topHorse.raceNumber,
      reason: `أفضل ترشيح في ${racecourse} بنسبة فوز متوقعة ${topHorse.winProbability}%`
    } : null
    
    const nextBest = secondHorse ? {
      horseName: secondHorse.horseName,
      raceNumber: secondHorse.raceNumber,
      reason: `خيار ثانٍ قوي في السباق ${secondHorse.raceNumber}`
    } : null
    
    // Find surprises (dark horses)
    const surprises = allHorses
      .filter(h => h.isSurprise && h.position >= 3)
      .slice(0, 2)
      .map(h => ({
        horseName: h.horseName,
        raceNumber: h.raceNumber,
        reason: `قد يكون مفاجأة السباق مع تصنيف ${h.rating}`
      }))
    
    // Top jockey, trainer, owner
    const topJockey = {
      name: jockeysByRegion[country]?.[0] || 'Top Jockey',
      winRate: `${18 + Math.floor(Math.random() * 5)}%`,
      horses: allHorses.filter(h => h.jockey === jockeysByRegion[country]?.[0]).map(h => h.horseName).slice(0, 3)
    }
    
    const topTrainer = {
      name: trainersByRegion[country]?.[0] || 'Top Trainer',
      winRate: `${22 + Math.floor(Math.random() * 5)}%`,
      horses: allHorses.filter(h => h.trainer === trainersByRegion[country]?.[0]).map(h => h.horseName).slice(0, 3)
    }
    
    const topOwner = {
      name: 'Godolphin',
      form: 'ممتاز',
      horses: allHorses.filter(h => h.owner === 'Godolphin').map(h => h.horseName).slice(0, 3)
    }

    const result = {
      success: true,
      racecourse,
      date,
      country,
      totalRaces: predictions.length,
      trackProfile: trackProfile ? {
        id: trackProfile.id,
        name: trackProfile.name,
        nameAr: trackProfile.nameAr,
        location: trackProfile.locationAr,
        surfaces: trackProfile.surfaces.map(s => ({
          type: s.type,
          typeAr: s.typeAr,
          circumference: s.circumference
        })),
        direction: trackProfile.trackCharacteristics.directionAr,
        specialFeatures: trackProfile.specialFeatures.slice(0, 5).map(f => ({
          name: f.name,
          nameAr: f.nameAr,
          impact: f.impact
        }))
      } : null,
      predictions,
      napOfTheDay,
      nextBest,
      surprises,
      topJockey,
      topTrainer,
      topOwner,
      sources: sources || ['racingpost.com', 'attheraces.com', 'skyracingworld.com'],
      rawAiResponse: null
    }

    return NextResponse.json(result)

  } catch (error) {
    console.error('Analyze error:', error)
    return NextResponse.json(
      { 
        success: false, 
        message: error instanceof Error ? error.message : 'Failed to analyze race data' 
      },
      { status: 500 }
    )
  }
}
