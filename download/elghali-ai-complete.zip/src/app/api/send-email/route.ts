import { NextRequest, NextResponse } from 'next/server'
import { 
  sendPredictionEmail, 
  sendTestEmail, 
  isEmailConfigured,
  getEmailConfig 
} from '@/lib/email-service'
import fs from 'fs'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, to, racecourse, date, pdfPath, napOfTheDay, totalRaces } = body

    // Handle test email
    if (action === 'test') {
      if (!to) {
        return NextResponse.json(
          { success: false, message: 'Email address is required for test' },
          { status: 400 }
        )
      }

      const result = await sendTestEmail(to)
      return NextResponse.json(result)
    }

    // Handle configuration check
    if (action === 'check') {
      const configured = isEmailConfigured()
      const config = getEmailConfig()
      
      return NextResponse.json({
        configured,
        server: config.server,
        port: config.port,
        username: config.username ? `${config.username.substring(0, 3)}***` : 'Not set',
        fromName: config.fromName,
        fromAddress: config.fromAddress
      })
    }

    // Handle prediction email
    if (!to || !pdfPath) {
      return NextResponse.json(
        { success: false, message: 'Email address and PDF path are required' },
        { status: 400 }
      )
    }

    // Check if PDF exists
    if (!fs.existsSync(pdfPath)) {
      return NextResponse.json({
        success: false,
        message: `PDF file not found: ${pdfPath}`
      })
    }

    // Send the email
    const result = await sendPredictionEmail(
      to,
      racecourse || 'Unknown',
      date || new Date().toLocaleDateString(),
      pdfPath,
      napOfTheDay || {
        horseName: 'N/A',
        raceName: 'N/A',
        reason: 'N/A'
      },
      totalRaces || 0
    )

    return NextResponse.json(result)

  } catch (error) {
    console.error('Send email error:', error)
    return NextResponse.json(
      { 
        success: false, 
        message: error instanceof Error ? error.message : 'Failed to send email' 
      },
      { status: 500 }
    )
  }
}

export async function GET() {
  const configured = isEmailConfigured()
  const config = getEmailConfig()
  
  return NextResponse.json({
    configured,
    server: config.server,
    port: config.port,
    username: config.username ? `${config.username.substring(0, 3)}***@${config.username.split('@')[1] || ''}` : 'Not set',
    fromName: config.fromName,
    fromAddress: config.fromAddress,
    message: configured 
      ? 'Email is configured and ready to send reports'
      : 'Email is not configured. Please set SMTP_USERNAME and SMTP_PASSWORD environment variables.'
  })
}
