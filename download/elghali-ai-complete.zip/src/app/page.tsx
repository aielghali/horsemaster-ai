'use client'

import { useState, useEffect, useCallback } from 'react'
import { format } from 'date-fns'
import { 
  CalendarIcon, 
  Loader2, 
  Mail, 
  MapPin, 
  Trophy, 
  AlertCircle, 
  CheckCircle2, 
  Download, 
  RefreshCw,
  Search,
  Brain,
  FileText,
  Send,
  ChevronDown,
  Globe
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Calendar as CalendarComponent } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Progress } from '@/components/ui/progress'
import { cn } from '@/lib/utils'

// Popular racecourses for suggestions
const POPULAR_RACECOURSES = [
  'Meydan',
  'Jebel Ali',
  'Abu Dhabi',
  'Sharjah',
  'Al Ain',
  'Ascot',
  'Newmarket',
  'Epsom',
  'York',
  'Cheltenham',
  'Aintree',
  'Santa Anita',
  'Belmont Park',
  'Churchill Downs',
  'Lone Star Park',
  'Del Mar',
  'Flemington',
  'Randwick',
  'Caulfield',
  'Moonee Valley'
]

// Translations
const translations = {
  ar: {
    // Header
    title: 'Elghali Ai',
    subtitle: 'ترشيحات سباقات الخيل الذكية',
    highAccuracy: 'دقة عالية في التنبؤ',
    
    // Introduction
    welcomeTitle: 'مرحباً بك في Elghali Ai',
    welcomeDesc: 'نظام الذكاء الاصطناعي المتخصص في تحليل سباقات الخيل وإنشاء ترشيحات دقيقة. يقوم النظام بالبحث في أفضل المصادر العالمية وتحليل البيانات لتقديم تنبؤات موثوقة.',
    
    // Form
    inputTitle: 'إدخال بيانات السباق',
    inputDesc: 'أدخل معلومات السباق للحصول على الترشيحات',
    raceDate: 'تاريخ السباق',
    selectDate: 'اختر التاريخ',
    racecourseLabel: 'اسم المضمار',
    racecoursePlaceholder: 'مثال: Meydan, Ascot, Santa Anita',
    popularTracks: 'المضارات الشائعة',
    emailLabel: 'البريد الإلكتروني',
    emailPlaceholder: 'example@email.com',
    emailHint: 'سيتم إرسال تقرير PDF إلى هذا البريد',
    startAnalysis: 'بدء التحليل',
    processing: 'جاري المعالجة...',
    reset: 'إعادة تعيين',
    
    // Progress Steps
    step1: 'البحث في المصادر...',
    step2: 'جمع البيانات...',
    step3: 'التحليل بالذكاء الاصطناعي...',
    step4: 'إنشاء التقرير...',
    step5: 'إرسال البريد الإلكتروني...',
    
    // Status
    processingTitle: 'جاري المعالجة',
    successTitle: 'تم بنجاح!',
    errorTitle: 'خطأ',
    
    // Results
    resultsTitle: 'نتائج الترشيحات',
    races: 'سباقات',
    napOfTheDay: 'ترشيح اليوم (NAP of the Day)',
    nextBest: 'الترشيح الثاني',
    allRacePredictions: 'ترشيحات جميع السباقات',
    position: 'المركز',
    horse: 'الحصان',
    rating: 'التصنيف',
    jockey: 'الفارس',
    probability: 'الاحتمال',
    race: 'السباق',
    analysis: 'تحليل',
    downloadPDF: 'تحميل تقرير PDF',
    emailSent: 'تم إرسال التقرير إلى بريدك الإلكتروني',
    reportCreated: 'تم إنشاء التقرير - يمكنك تحميله مباشرة',
    
    // Info Cards
    advancedAnalysis: 'تحليل متقدم',
    advancedAnalysisDesc: 'تحليل بيانات شامل من مصادر متعددة',
    dailyUpdates: 'تحديثات يومية',
    dailyUpdatesDesc: 'ترشيحات محدثة لكل يوم سباق',
    pdfReports: 'تقارير PDF',
    pdfReportsDesc: 'تقارير مفصلة تُرسل إلى بريدك',
    
    // Footer
    copyright: '© 2025 Elghali Ai - جميع الحقوق محفوظة',
    disclaimer: 'نظام الترشيحات يعتمد على تحليل الذكاء الاصطناعي - المراهنة تنطوي على مخاطر',
    
    // Validation
    fillAllFields: 'الرجاء إدخال جميع الحقول المطلوبة',
    validEmail: 'الرجاء إدخال بريد إلكتروني صحيح',
    searchingSources: 'جاري البحث عن بيانات السباقات...',
    errorOccurred: 'حدث خطأ أثناء إنشاء الترشيحات',
    connectionError: 'حدث خطأ في الاتصال بالخادم'
  },
  en: {
    // Header
    title: 'Elghali Ai',
    subtitle: 'Intelligent Horse Racing Predictions',
    highAccuracy: 'High Prediction Accuracy',
    
    // Introduction
    welcomeTitle: 'Welcome to Elghali Ai',
    welcomeDesc: 'An AI system specialized in analyzing horse races and creating accurate predictions. The system searches the best global sources and analyzes data to provide reliable predictions.',
    
    // Form
    inputTitle: 'Race Information Input',
    inputDesc: 'Enter race details to get predictions',
    raceDate: 'Race Date',
    selectDate: 'Select Date',
    racecourseLabel: 'Racecourse Name',
    racecoursePlaceholder: 'e.g., Meydan, Ascot, Santa Anita',
    popularTracks: 'Popular Tracks',
    emailLabel: 'Email Address',
    emailPlaceholder: 'example@email.com',
    emailHint: 'PDF report will be sent to this email',
    startAnalysis: 'Start Analysis',
    processing: 'Processing...',
    reset: 'Reset',
    
    // Progress Steps
    step1: 'Searching sources...',
    step2: 'Collecting data...',
    step3: 'Analyzing with Elghali Ai...',
    step4: 'Generating report...',
    step5: 'Sending email...',
    
    // Status
    processingTitle: 'Processing',
    successTitle: 'Success!',
    errorTitle: 'Error',
    
    // Results
    resultsTitle: 'Prediction Results',
    races: 'Races',
    napOfTheDay: 'NAP of the Day',
    nextBest: 'Next Best',
    allRacePredictions: 'All Race Predictions',
    position: 'Position',
    horse: 'Horse',
    rating: 'Rating',
    jockey: 'Jockey',
    probability: 'Probability',
    race: 'Race',
    analysis: 'Analysis',
    downloadPDF: 'Download PDF Report',
    emailSent: 'Report sent to your email',
    reportCreated: 'Report created - you can download it directly',
    
    // Info Cards
    advancedAnalysis: 'Advanced Analysis',
    advancedAnalysisDesc: 'Comprehensive data analysis from multiple sources',
    dailyUpdates: 'Daily Updates',
    dailyUpdatesDesc: 'Updated predictions for every race day',
    pdfReports: 'PDF Reports',
    pdfReportsDesc: 'Detailed reports sent to your email',
    
    // Footer
    copyright: '© 2025 Elghali Ai - All Rights Reserved',
    disclaimer: 'Predictions are based on AI analysis - Betting involves risks',
    
    // Validation
    fillAllFields: 'Please fill in all required fields',
    validEmail: 'Please enter a valid email address',
    searchingSources: 'Searching for race data...',
    errorOccurred: 'An error occurred while generating predictions',
    connectionError: 'A connection error occurred'
  }
}

interface PredictionResult {
  success: boolean
  message: string
  racecourse: string
  date: string
  totalRaces: number
  predictions: {
    raceNumber: number
    raceName: string
    raceTime: string
    surface: string
    predictions: {
      position: number
      horseName: string
      rating: string
      jockey: string
      winProbability: string
      analysis: string
    }[]
  }[]
  napOfTheDay: {
    horseName: string
    raceName: string
    reason: string
  }
  nextBest: {
    horseName: string
    raceName: string
    reason: string
  }
  pdfPath?: string
  emailSent?: boolean
}

type Language = 'ar' | 'en'

export default function Home() {
  const [language, setLanguage] = useState<Language>('ar')
  const t = translations[language]
  const isRTL = language === 'ar'
  
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [racecourse, setRacecourse] = useState('')
  const [email, setEmail] = useState('ai.elghali.ali@gmail.com')
  const [isLoading, setIsLoading] = useState(false)
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')
  const [statusMessage, setStatusMessage] = useState('')
  const [result, setResult] = useState<PredictionResult | null>(null)
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [filteredSuggestions, setFilteredSuggestions] = useState<string[]>([])
  const [currentStep, setCurrentStep] = useState(0)
  const [stepProgress, setStepProgress] = useState(0)

  // Filter racecourse suggestions
  useEffect(() => {
    if (racecourse.length > 0) {
      const filtered = POPULAR_RACECOURSES.filter(rc => 
        rc.toLowerCase().includes(racecourse.toLowerCase())
      )
      setFilteredSuggestions(filtered)
    } else {
      setFilteredSuggestions(POPULAR_RACECOURSES)
    }
  }, [racecourse])

  // Simulate progress during loading
  useEffect(() => {
    if (isLoading) {
      const stepInterval = setInterval(() => {
        setCurrentStep(prev => {
          if (prev < 4) return prev + 1
          return prev
        })
      }, 3000)

      const progressInterval = setInterval(() => {
        setStepProgress(prev => {
          if (prev < 95) return prev + Math.random() * 5
          return prev
        })
      }, 500)

      return () => {
        clearInterval(stepInterval)
        clearInterval(progressInterval)
      }
    } else {
      if (status === 'success') {
        setStepProgress(100)
        setCurrentStep(5)
      }
    }
  }, [isLoading, status])

  const handleGeneratePredictions = async () => {
    if (!date || !racecourse.trim() || !email.trim()) {
      setStatus('error')
      setStatusMessage(t.fillAllFields)
      return
    }

    if (!email.includes('@') || !email.includes('.')) {
      setStatus('error')
      setStatusMessage(t.validEmail)
      return
    }

    setIsLoading(true)
    setStatus('loading')
    setStatusMessage(t.searchingSources)
    setCurrentStep(0)
    setStepProgress(0)
    setResult(null)

    try {
      // Step 1: Search for race data
      setCurrentStep(0)
      setStepProgress(10)
      setStatusMessage(t.step1)
      
      const searchResponse = await fetch('/api/search-races', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          date: format(date, 'yyyy-MM-dd'),
          racecourse: racecourse.trim()
        }),
      })
      const searchData = await searchResponse.json()
      setStepProgress(25)
      
      // Step 2: Collect data
      setCurrentStep(1)
      setStatusMessage(t.step2)
      setStepProgress(40)
      
      // Step 3: Analyze with AI
      setCurrentStep(2)
      setStatusMessage(t.step3)
      
      const analyzeResponse = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          date: format(date, 'yyyy-MM-dd'),
          racecourse: racecourse.trim(),
          searchData: searchData.rawContent,
          sources: searchData.sources
        }),
      })
      const analyzeData = await analyzeResponse.json()
      setStepProgress(60)
      
      if (!analyzeResponse.ok) {
        throw new Error(analyzeData.message || t.errorOccurred)
      }
      
      // Step 4: Generate PDF report
      setCurrentStep(3)
      setStatusMessage(t.step4)
      setStepProgress(75)
      
      const reportResponse = await fetch('/api/generate-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(analyzeData),
      })
      const reportData = await reportResponse.json()
      setStepProgress(85)
      
      // Step 5: Send email
      setCurrentStep(4)
      setStatusMessage(t.step5)
      setStepProgress(90)
      
      let emailSent = false
      if (reportData.success && reportData.absolutePath) {
        const emailResponse = await fetch('/api/send-email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to: email.trim(),
            racecourse: analyzeData.racecourse,
            date: analyzeData.date,
            pdfPath: reportData.absolutePath,
            napOfTheDay: analyzeData.napOfTheDay,
            totalRaces: analyzeData.totalRaces
          }),
        })
        const emailData = await emailResponse.json()
        emailSent = emailData.success
      }
      
      setStepProgress(100)
      setCurrentStep(5)
      
      setStatus('success')
      setStatusMessage(t.successTitle)
      setResult({
        ...analyzeData,
        pdfPath: reportData.pdfPath,
        emailSent
      })
      
    } catch (error) {
      console.error('Error generating predictions:', error)
      setStatus('error')
      setStatusMessage(error instanceof Error ? error.message : t.connectionError)
    } finally {
      setIsLoading(false)
    }
  }

  const handleDownloadPDF = () => {
    if (result?.pdfPath) {
      window.open(result.pdfPath, '_blank')
    }
  }

  const handleReset = () => {
    setDate(new Date())
    setRacecourse('')
    setEmail('ai.elghali.ali@gmail.com')
    setStatus('idle')
    setStatusMessage('')
    setResult(null)
    setCurrentStep(0)
    setStepProgress(0)
  }

  const getStepIcon = (stepIndex: number) => {
    if (currentStep > stepIndex) {
      return <CheckCircle2 className="w-4 h-4 text-green-500" />
    } else if (currentStep === stepIndex) {
      return <Loader2 className="w-4 h-4 animate-spin text-amber-500" />
    }
    return <div className="w-2 h-2 rounded-full bg-gray-300" />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-red-50" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Header */}
      <header className="bg-gradient-to-l from-red-900 via-red-800 to-red-900 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <img 
                src="/elghali-logo.png" 
                alt="Elghali Ai Logo" 
                className="w-16 h-16 rounded-full shadow-lg border-2 border-amber-400"
              />
              <div>
                <h1 className="text-3xl font-bold text-amber-400">{t.title}</h1>
                <p className="text-amber-200 text-sm">{t.subtitle}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              {/* Language Toggle */}
              <Button
                variant="ghost"
                onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
                className="text-amber-200 hover:text-amber-400 hover:bg-red-950/50"
              >
                <Globe className="w-4 h-4 mr-2" />
                {language === 'ar' ? 'English' : 'العربية'}
              </Button>
              <div className="hidden md:flex items-center gap-2 bg-red-950/50 px-4 py-2 rounded-full">
                <Trophy className="w-5 h-5 text-amber-400" />
                <span className="text-amber-200 text-sm">{t.highAccuracy}</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Introduction Card */}
          <Card className="mb-8 border-amber-200 bg-gradient-to-l from-amber-50 to-white">
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-red-900 rounded-lg">
                  <Trophy className="w-8 h-8 text-amber-400" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-red-900 mb-2">{t.welcomeTitle}</h2>
                  <p className="text-gray-600 leading-relaxed">{t.welcomeDesc}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Input Form */}
          <Card className="mb-8 shadow-lg border-amber-200">
            <CardHeader className="bg-gradient-to-l from-red-900 to-red-800 text-white rounded-t-lg">
              <CardTitle className="flex items-center gap-2 text-amber-400">
                <CalendarIcon className="w-5 h-5" />
                {t.inputTitle}
              </CardTitle>
              <CardDescription className="text-amber-200">
                {t.inputDesc}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              {/* Date Picker */}
              <div className="space-y-2">
                <Label htmlFor="date" className="text-red-900 font-bold flex items-center gap-2">
                  <CalendarIcon className="w-4 h-4" />
                  {t.raceDate}
                </Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-between bg-white border-amber-200 hover:bg-amber-50",
                        isRTL ? "text-right" : "text-left",
                        !date && "text-muted-foreground"
                      )}
                    >
                      {date ? format(date, 'EEEE, d MMMM yyyy') : t.selectDate}
                      <CalendarIcon className={cn("h-4 w-4", isRTL ? "mr-2" : "ml-2")} />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <CalendarComponent
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              {/* Racecourse Input */}
              <div className="space-y-2">
                <Label htmlFor="racecourse" className="text-red-900 font-bold flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  {t.racecourseLabel}
                </Label>
                <div className="relative">
                  <Input
                    id="racecourse"
                    type="text"
                    placeholder={t.racecoursePlaceholder}
                    value={racecourse}
                    onChange={(e) => setRacecourse(e.target.value)}
                    onFocus={() => setShowSuggestions(true)}
                    onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                    className="bg-white border-amber-200 focus:border-red-900 focus:ring-red-900"
                  />
                  {showSuggestions && filteredSuggestions.length > 0 && (
                    <div className="absolute z-10 w-full mt-1 bg-white border border-amber-200 rounded-md shadow-lg max-h-48 overflow-y-auto">
                      {filteredSuggestions.map((rc) => (
                        <div
                          key={rc}
                          className={cn(
                            "px-4 py-2 hover:bg-amber-50 cursor-pointer",
                            isRTL ? "text-right" : "text-left"
                          )}
                          onClick={() => {
                            setRacecourse(rc)
                            setShowSuggestions(false)
                          }}
                        >
                          {rc}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <p className="text-xs text-gray-500">{t.popularTracks}: Meydan, Ascot, Churchill Downs, ...</p>
              </div>

              {/* Email Input */}
              <div className="space-y-2">
                <Label htmlFor="email" className="text-red-900 font-bold flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  {t.emailLabel}
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder={t.emailPlaceholder}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-white border-amber-200 focus:border-red-900 focus:ring-red-900"
                  dir="ltr"
                />
                <p className="text-xs text-gray-500">{t.emailHint}</p>
              </div>

              {/* Submit Button */}
              <div className="flex gap-4 pt-4">
                <Button
                  onClick={handleGeneratePredictions}
                  disabled={isLoading}
                  className="flex-1 bg-gradient-to-l from-red-900 to-red-800 hover:from-red-800 hover:to-red-700 text-white py-6 text-lg"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className={cn("w-5 h-5 animate-spin", isRTL ? "ml-2" : "mr-2")} />
                      {t.processing}
                    </>
                  ) : (
                    <>
                      <Trophy className={cn("w-5 h-5", isRTL ? "ml-2" : "mr-2")} />
                      {t.startAnalysis}
                    </>
                  )}
                </Button>
                {status !== 'idle' && (
                  <Button
                    variant="outline"
                    onClick={handleReset}
                    disabled={isLoading}
                    className="border-red-900 text-red-900 hover:bg-red-50"
                  >
                    <RefreshCw className={cn("w-4 h-4", isRTL ? "ml-2" : "mr-2")} />
                    {t.reset}
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Progress Display */}
          {isLoading && (
            <Card className="mb-8 border-amber-200">
              <CardContent className="p-6">
                <div className="space-y-4">
                  {/* Progress Bar */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-amber-700 font-medium">{statusMessage}</span>
                      <span className="text-gray-500">{Math.round(stepProgress)}%</span>
                    </div>
                    <Progress value={stepProgress} className="h-2" />
                  </div>
                  
                  {/* Step Indicators */}
                  <div className="grid grid-cols-5 gap-2 mt-4">
                    {[
                      { icon: Search, label: t.step1 },
                      { icon: MapPin, label: t.step2 },
                      { icon: Brain, label: t.step3 },
                      { icon: FileText, label: t.step4 },
                      { icon: Send, label: t.step5 }
                    ].map((step, index) => (
                      <div 
                        key={index}
                        className={cn(
                          "flex flex-col items-center p-2 rounded-lg transition-all",
                          currentStep === index && "bg-amber-100 border border-amber-300",
                          currentStep > index && "bg-green-50 border border-green-200",
                          currentStep < index && "bg-gray-50 border border-gray-200"
                        )}
                      >
                        {getStepIcon(index)}
                        <span className={cn(
                          "text-xs mt-1 text-center",
                          currentStep === index && "text-amber-700 font-medium",
                          currentStep > index && "text-green-600",
                          currentStep < index && "text-gray-400"
                        )}>
                          {step.label}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Status Messages */}
          {status !== 'idle' && !isLoading && (
            <Card className="mb-8">
              <CardContent className="p-4">
                {status === 'success' && (
                  <Alert className="border-green-200 bg-green-50">
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                    <AlertTitle className="text-green-800">{t.successTitle}</AlertTitle>
                    <AlertDescription className="text-green-700">
                      {statusMessage}
                    </AlertDescription>
                  </Alert>
                )}
                {status === 'error' && (
                  <Alert variant="destructive">
                    <AlertCircle className="w-4 h-4" />
                    <AlertTitle>{t.errorTitle}</AlertTitle>
                    <AlertDescription>{statusMessage}</AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          )}

          {/* Results Preview */}
          {result && (
            <Card className="mb-8 shadow-lg border-amber-200">
              <CardHeader className="bg-gradient-to-l from-red-900 to-red-800 text-white rounded-t-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-amber-400 flex items-center gap-2">
                      <Trophy className="w-5 h-5" />
                      {t.resultsTitle}
                    </CardTitle>
                    <CardDescription className="text-amber-200">
                      {result.racecourse} - {result.date}
                    </CardDescription>
                  </div>
                  <Badge className="bg-amber-400 text-red-900 text-lg px-3 py-1">
                    {result.totalRaces} {t.races}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                {/* NAP of the Day */}
                <div className="mb-6 p-4 bg-gradient-to-l from-amber-50 to-amber-100 rounded-lg border border-amber-200">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-2xl">🌟</span>
                    <h3 className="font-bold text-red-900 text-lg">{t.napOfTheDay}</h3>
                  </div>
                  <div className="flex items-center gap-4 flex-wrap">
                    <div className="text-2xl font-bold text-amber-700">
                      {result.napOfTheDay.horseName}
                    </div>
                    <Badge variant="outline" className="border-red-900 text-red-900">
                      {result.napOfTheDay.raceName}
                    </Badge>
                  </div>
                  <p className="text-gray-600 mt-2 text-sm">{result.napOfTheDay.reason}</p>
                </div>

                {/* Next Best */}
                <div className="mb-6 p-4 bg-gradient-to-l from-gray-50 to-gray-100 rounded-lg border border-gray-200">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xl">⭐</span>
                    <h3 className="font-bold text-gray-700">{t.nextBest}</h3>
                  </div>
                  <div className="flex items-center gap-4 flex-wrap">
                    <div className="text-xl font-bold text-gray-600">
                      {result.nextBest.horseName}
                    </div>
                    <Badge variant="outline" className="border-gray-600 text-gray-600">
                      {result.nextBest.raceName}
                    </Badge>
                  </div>
                  <p className="text-gray-500 mt-2 text-sm">{result.nextBest.reason}</p>
                </div>

                <Separator className="my-6" />

                {/* All Races Predictions */}
                <h3 className="font-bold text-red-900 mb-4 flex items-center gap-2">
                  <Trophy className="w-4 h-4" />
                  {t.allRacePredictions}
                </h3>
                <ScrollArea className="h-96 rounded-lg border border-amber-200">
                  <div className="p-4 space-y-4">
                    {result.predictions.map((race, index) => (
                      <div key={index} className="bg-white p-4 rounded-lg border border-amber-100 shadow-sm">
                        <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                          <div>
                            <h4 className="font-bold text-red-900">{race.raceName}</h4>
                            <p className="text-sm text-gray-500">
                              {race.raceTime} • {race.surface}
                            </p>
                          </div>
                          <Badge variant="secondary" className="bg-amber-100 text-amber-800">
                            {t.race} {race.raceNumber}
                          </Badge>
                        </div>
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="border-b border-amber-200">
                                <th className={cn("py-2 px-2 text-red-900", isRTL ? "text-right" : "text-left")}>{t.position}</th>
                                <th className={cn("py-2 px-2 text-red-900", isRTL ? "text-right" : "text-left")}>{t.horse}</th>
                                <th className={cn("py-2 px-2 text-red-900", isRTL ? "text-right" : "text-left")}>{t.rating}</th>
                                <th className={cn("py-2 px-2 text-red-900", isRTL ? "text-right" : "text-left")}>{t.jockey}</th>
                                <th className={cn("py-2 px-2 text-red-900", isRTL ? "text-right" : "text-left")}>{t.probability}</th>
                              </tr>
                            </thead>
                            <tbody>
                              {race.predictions.map((pred, predIndex) => (
                                <tr 
                                  key={predIndex} 
                                  className={cn(
                                    "border-b border-amber-50",
                                    predIndex === 0 && "bg-amber-50",
                                    predIndex === 1 && "bg-gray-50",
                                    predIndex === 2 && "bg-orange-50"
                                  )}
                                >
                                  <td className="py-2 px-2">
                                    <span className={cn(
                                      "inline-flex items-center gap-1 font-bold",
                                      predIndex === 0 && "text-amber-600",
                                      predIndex === 1 && "text-gray-500",
                                      predIndex === 2 && "text-orange-600"
                                    )}>
                                      {predIndex === 0 && '🥇'}
                                      {predIndex === 1 && '🥈'}
                                      {predIndex === 2 && '🥉'}
                                      {pred.position}
                                    </span>
                                  </td>
                                  <td className="py-2 px-2 font-medium">{pred.horseName}</td>
                                  <td className="py-2 px-2">{pred.rating || '-'}</td>
                                  <td className="py-2 px-2">{pred.jockey || '-'}</td>
                                  <td className="py-2 px-2">
                                    <span className={cn(
                                      "font-bold",
                                      (pred.winProbability.includes('50') || pred.winProbability.includes('60') || pred.winProbability.includes('70'))
                                        ? "text-green-600" 
                                        : "text-amber-600"
                                    )}>
                                      {pred.winProbability}
                                    </span>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                        {race.predictions[0]?.analysis && (
                          <p className="text-xs text-gray-500 mt-2 border-t border-amber-100 pt-2">
                            <strong>{t.analysis}:</strong> {race.predictions[0].analysis}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>

                {/* Actions */}
                <div className="flex gap-4 mt-6">
                  {result.pdfPath && (
                    <Button
                      onClick={handleDownloadPDF}
                      className="flex-1 bg-gradient-to-l from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white"
                    >
                      <Download className={cn("w-4 h-4", isRTL ? "ml-2" : "mr-2")} />
                      {t.downloadPDF}
                    </Button>
                  )}
                </div>

                {/* Email Status */}
                {result.emailSent !== undefined && (
                  <div className={cn(
                    "mt-4 p-3 rounded-lg flex items-center gap-2",
                    result.emailSent ? "bg-green-50 text-green-700" : "bg-amber-50 text-amber-700"
                  )}>
                    {result.emailSent ? (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>{t.emailSent}</span>
                      </>
                    ) : (
                      <>
                        <AlertCircle className="w-4 h-4" />
                        <span>{t.reportCreated}</span>
                      </>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Info Cards */}
          <div className="grid md:grid-cols-3 gap-4">
            <Card className="border-amber-200">
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Trophy className="w-6 h-6 text-amber-600" />
                  </div>
                  <h3 className="font-bold text-red-900 mb-1">{t.advancedAnalysis}</h3>
                  <p className="text-sm text-gray-500">{t.advancedAnalysisDesc}</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-amber-200">
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <CalendarIcon className="w-6 h-6 text-red-600" />
                  </div>
                  <h3 className="font-bold text-red-900 mb-1">{t.dailyUpdates}</h3>
                  <p className="text-sm text-gray-500">{t.dailyUpdatesDesc}</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-amber-200">
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Mail className="w-6 h-6 text-green-600" />
                  </div>
                  <h3 className="font-bold text-red-900 mb-1">{t.pdfReports}</h3>
                  <p className="text-sm text-gray-500">{t.pdfReportsDesc}</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-red-900 text-white py-6 mt-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-amber-200">{t.copyright}</p>
          <p className="text-amber-400 text-sm mt-2">
            {t.disclaimer}
          </p>
        </div>
      </footer>
    </div>
  )
}
